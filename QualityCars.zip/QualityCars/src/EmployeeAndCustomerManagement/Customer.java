/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeAndCustomerManagement;

import StockMaintenance.Vehicles;
import java.util.Date;

/**
 *
 * @author rbhaskar
 */
public class Customer extends Person{
    private String licenseNumber;
    private int age;
    private Date licenseExpiry;

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getLicenseExpiry() {
        return licenseExpiry;
    }

    public void setLicenseExpiry(Date licenseExpiry) {
        this.licenseExpiry = licenseExpiry;
    }

    public Customer(String licenseNumber, int age, Date licenseExpiry, int personID, String name, Date dob, String address, String telephoneNumber) {
        super(personID, name, dob, address, telephoneNumber);
        this.licenseNumber = licenseNumber;
        this.age = age;
        this.licenseExpiry = licenseExpiry;
    }
    
    @Override
    public void borrowVehicle(Vehicles vehicle, Date returnDue)
    {
        
    }
    
    @Override
    public void returnVehicle(Vehicles vehicle)
    {
        
    }
    
}
